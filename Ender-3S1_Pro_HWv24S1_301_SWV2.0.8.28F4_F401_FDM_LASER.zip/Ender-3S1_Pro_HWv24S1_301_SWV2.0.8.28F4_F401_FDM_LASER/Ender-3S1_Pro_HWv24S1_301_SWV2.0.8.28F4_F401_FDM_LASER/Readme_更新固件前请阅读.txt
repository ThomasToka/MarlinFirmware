------------------------------------------------------------------------------
 固件适用机型及主板版本

 打印机型号：Ender-3 S1 Pro
主板主控芯片型号： STM32F401
说明：
  该固件为Ender-3 S1 Pro 升级版本，支持九国语言，支持加装激光打印模块，更新后可切换FDM和激光打印。更新固件前请确认主控芯片型号，仅支持主控芯片是F401版本的机型。


固件更新内容：
    1.新增模型图片预览功能
    2.支持高速打印(160mm/s) & 振纹优化
    3.支持自动PID设置
    4.可展示/编辑调平数据
  
屏幕更新说明：
    1. 在电脑端格式化TF卡，分配单元大小选择4096。
    2.将“private”、“DWIN_SET”文件夹和firmware.zlib放入TF卡。
    3.关闭打印机，将TF卡插入屏幕背面卡槽。
    4. 重启等待更新完成。
    5.完成更新后取出TF卡，并删除里面的内容。
主板更新：
   1. 在电脑端格式化SD卡，分配单元大小选择4096。
   1. 将STM32F4_UPDATE文件夹放入SD卡(这一步骤是必须的，请注意）。
   3. 关闭打印机，将SD卡插入主板卡槽。
   4. 重启等待更新完成。
   5. 完成更新后取出SD卡，并删除里面的文件。

视频教程：
https://www.crealitycloud.cn/post-detail/6260f79cbcc725c804720cd9

-------------------------------------------------------------------------------
Printer: Ender-3 S1 Pro
Motherboard main control chip version: STM32F401
Notes: 
  The firmware is Ender-3 S1 Pro update version, Support nine languages, support adding laser printing module, after updating, you can switch between FDM and laser printing. Please confirm the main control chip model before updating the firmware, only support the model whose main control chip is F401 version.

Firmware update contents:
    1. New model picture preview function
    2. Support high-speed printing (160mm/s) & optimization of vibration pattern
    3. Support automatic PID setting
    4. Display/edit leveling data
  
Display firmware update：
    1. Format the TF card on the computer side, and select 4096 for the allocation unit size.
    2. Put the file "private" 、“DWIN_SET”and “firmware.zlib”into the TF card at
    the same time.
    3. Turn off the printer and insert the TF card into the card slot on the back of the screen.
    4. Reboot and wait for the update to finish.
    5. After finishing the update, remove the TF card and delete the files inside.


Mainboard firmware update：
   1. Format the SD card on the computer side, and select 4096 for the allocation unit size.
   2. Put the STM32F4_UPDATE folder into the SD card  (THIS STEP IS REQUIRED， PLEASE NOTE！).
   3. Turn off the printer and insert the SD card into the card slot on the motherboard.  
   4. Reboot and wait for the update to finish.
   5. After finishing the update, remove the SD card from the motherboard slot and delete  file inside.

video tutorial：
https://www.crealitycloud.com/post-detail/6260f8046a165bebd55811fb
